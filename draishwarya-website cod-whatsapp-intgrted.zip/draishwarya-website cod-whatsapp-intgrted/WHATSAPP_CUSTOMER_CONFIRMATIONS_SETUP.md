# Customer WhatsApp confirmations: appointments + COD orders

## What happens
- COD order: after `create-order` saves the order, it sends an approved WhatsApp template to the customer phone from checkout only when the customer checked the WhatsApp opt-in box. Existing MSG91 COD SMS remains enabled if configured. A messaging failure does not cancel the saved order.
- Appointment: after Razorpay server-side verification or a valid payment webhook confirms payment, the appointment WhatsApp template is sent to the phone number entered by the person booking. It is sent only when they checked the WhatsApp consent box.
- Phone numbers are normalized to digits; a 10-digit Indian number receives the `91` country prefix. International numbers should include country code.
- The WhatsApp API returning accepted is not proof of delivery; verify Meta message status and the recipient's phone.

## 1. Apply the database migration
Run `supabase/migrations/20261024_customer_whatsapp_optin.sql` in Supabase SQL Editor after confirming this is the correct project. This adds `whatsapp_opt_in` to `orders` and `appointments`; it does not drop data.

## 2. Configure Supabase Edge Function secrets
Required for WhatsApp Cloud API:
- `WHATSAPP_ACCESS_TOKEN` — secure server-side token
- `WHATSAPP_PHONE_NUMBER_ID` — Meta WhatsApp Cloud API phone number ID, not the visible phone number
- `WHATSAPP_TEMPLATE_LANG` — approved template language, e.g. `en`
- `WHATSAPP_APPOINTMENT_TEMPLATE` — approved appointment template name
- `WHATSAPP_COD_TEMPLATE` — approved COD order template name

Do not put these secrets in `index.html`, Netlify environment variables used by the static browser page, or a public ZIP.

## 3. Create/approve the templates in Meta WhatsApp Manager
Appointment template body has 5 text variables in this order: patient name, appointment reference, date, time, fee. Example: `Hello {{1}}, your appointment reference {{2}} is confirmed for {{3}} at {{4}} IST. Fee: INR {{5}}. Reply to this message if you need help.`

COD template body has 4 text variables in this order: customer name, order ID, total amount, payment method. Example: `Hello {{1}}, your order {{2}} has been placed. Total: {{3}}. Payment method: {{4}}. We will send further updates as your order progresses.`

The templates must be approved and the parameter count/order must match exactly. For business-initiated messages outside Meta's customer-service window, an approved template is normally required. Obtain explicit opt-in; the website checkboxes are unchecked by default.

## 4. Deploy the changed functions
From the project root folder (the folder containing `index.html` and `supabase`):
```powershell
npx supabase functions deploy create-order
npx supabase functions deploy create-appointment-razorpay-order
npx supabase functions deploy verify-appointment-razorpay-payment
npx supabase functions deploy razorpay-webhook --no-verify-jwt
```
Only deploy after linking to the intended Supabase project and reviewing the diff. Keep Razorpay and Supabase server secrets only in Supabase Edge Function Secrets.

## 5. End-to-end tests
1. Use Razorpay TEST MODE and a test appointment with a phone number you control. Check the WhatsApp consent box and finish payment. Confirm appointment is `Confirmed`/`Paid`, then check WhatsApp on that exact customer number and Meta logs.
2. Place a COD order with a phone number you control and check the COD WhatsApp consent box. Confirm the order row is created before inspecting the message. Verify the customer WhatsApp number, order ID and total.
3. Repeat with the checkbox unchecked: the order/appointment should still work, but no WhatsApp should be sent.
4. Temporarily use an invalid template name in a non-production test project to confirm failure is logged and the order/appointment remains saved. Restore the correct template name afterward.
5. Check Supabase Edge Function logs and Meta WhatsApp Manager message logs. HTTP `accepted` means submitted, not necessarily delivered.

## Notes
- SMS and email are separate channels and require their own credentials/configuration.
- The appointment test build uses ₹5; do not use that fee for real customers.
- This code package is not deployed automatically. Test and publish the reviewed files yourself after applying the migration and secrets.
