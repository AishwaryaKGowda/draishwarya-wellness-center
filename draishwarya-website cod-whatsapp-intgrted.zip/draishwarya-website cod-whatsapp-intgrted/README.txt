Dr Aishwarya Wellness Center — payment and booking extension
===========================================================

The existing single-page website and Supabase Edge Functions are retained. New functions extend the current project; they do not replace Netlify or Razorpay.

Implemented in this package
---------------------------
- Appointment booking starts Razorpay checkout for ₹250 / 30 minutes.
- Appointment status changes to Confirmed only after server-side payment verification or a valid Razorpay webhook.
- Appointment payment reservations expire after 15 minutes (requires migration).
- Product checkout supports COD, full Razorpay payment, and ₹200 advance + COD balance.
- Payment failures show a bank/retry warning and advise checking the clinic dashboard before paying again if funds may have been deducted.
- Razorpay webhook handler validates the webhook signature and reconciles appointment/order payment state.
- Appointment confirmation email via Resend and optional WhatsApp message via Meta Cloud API can be enabled with server-side secrets.
- My Account includes private medical-file upload for PDF/JPG/PNG up to 10 MB, linked to an appointment reference.
- SQL migration adds payment tracking columns and private storage policies.

Before testing
--------------
1. Read PAYMENT_AND_AUTH_SETUP.md completely.
2. Run the SQL migration in Supabase SQL Editor after reviewing your actual schema.
3. Add all required values as Supabase Edge Function secrets. Do not put server secrets in index.html or a downloadable .env file.
4. Deploy the Edge Functions listed in PAYMENT_AND_AUTH_SETUP.md.
5. Configure Razorpay webhook URL and secret in Razorpay Dashboard.
6. Use Razorpay test mode first and verify database rows before going live.

Not live until credentials are configured
-----------------------------------------
- Easebuzz fallback is not active in this package because the clinic's Easebuzz merchant key/salt and callback configuration were not supplied. Do not show it as a working option until the provider flow is configured and tested.
- Email requires RESEND_API_KEY and APPOINTMENT_FROM_EMAIL.
- WhatsApp requires WHATSAPP_ACCESS_TOKEN and WHATSAPP_PHONE_NUMBER_ID. A production template may be required by Meta outside the customer-service window.

The project is a static index.html website with Supabase Edge Functions, suitable for deployment on Netlify. Keep your existing Netlify site and Razorpay account.


Admin notifications integration (2026-10-23)
--------------------------------------------
- Apply supabase/migrations/20261023_admin_notification_events.sql after reviewing the schema.
- Creates in-app admin notification records for Auth signups and order/payment/COD state changes.
- The admin Notifications page shows unread counts, event details and a mark-all-read action.
- In-app alerts do not mean email, SMS or WhatsApp was sent. Delivery providers must be configured and tested separately.

CURRENT TEST BUILD NOTICE (2026-10-22)
-------------------------------------
- Appointment checkout fee is temporarily ₹5 (TEST ONLY) in the website, create-order function, verification function and webhook validation.
- Use Razorpay TEST MODE keys only. Do not deploy this price for public customers.
- Appointment confirmation email includes a WhatsApp contact link and QR code. Automatic SMS and WhatsApp delivery require MSG91/Meta credentials and approved templates.
- See TEST_CASES_AND_BIGROCK_DEPLOYMENT.md for test cases and BigRock cPanel hosting steps.
- Before production, restore the clinic's approved appointment fee consistently across frontend and all server functions, then repeat the test suite.
