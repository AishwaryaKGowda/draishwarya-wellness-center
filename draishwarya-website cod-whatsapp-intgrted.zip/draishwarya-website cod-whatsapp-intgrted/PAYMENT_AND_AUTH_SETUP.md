# Dr. Aishwarya Wellness Center — Payment, Notifications and Hosting Setup

## Important: ₹5 is a temporary TEST fee

The appointment booking UI and the appointment payment functions currently use **₹5 (TEST ONLY)** so you can run the requested end-to-end test. Use Razorpay **Test Mode keys only**. Do not deploy this price for real customers. Before production, restore the approved consultation fee consistently in `index.html`, `create-appointment-razorpay-order`, `verify-appointment-razorpay-payment`, and `razorpay-webhook`.

## Architecture

- Static website: `index.html`
- Website hosting: BigRock shared hosting/cPanel can host the static HTML over HTTPS.
- Database, Auth and Edge Functions: Supabase (these stay hosted by Supabase, even if the website is on BigRock).
- Payments: Razorpay Checkout with server-side signature and payment API verification.
- Notifications: Resend email, MSG91 SMS and Meta WhatsApp Cloud API; each channel requires credentials and approved sender/template setup.

## Secrets

Configure secrets in Supabase Dashboard → Edge Functions → Secrets. Never place server secrets in `index.html` or `.env` files uploaded to public hosting.

Required for appointment payment:
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `RAZORPAY_KEY_ID`
- `RAZORPAY_KEY_SECRET`

Email:
- `RESEND_API_KEY`
- `APPOINTMENT_FROM_EMAIL` — sender address verified in Resend

SMS via MSG91:
- `MSG91_AUTH_KEY`
- `MSG91_APPOINTMENT_TEMPLATE_ID` — DLT-approved appointment SMS template

WhatsApp Cloud API:
- `WHATSAPP_ACCESS_TOKEN`
- `WHATSAPP_PHONE_NUMBER_ID` — numeric Cloud API phone-number ID, not the displayed clinic phone
- `WHATSAPP_APPOINTMENT_TEMPLATE` — Meta-approved template name
- `WHATSAPP_TEMPLATE_LANG` — e.g. `en`

Webhook:
- `RAZORPAY_WEBHOOK_SECRET` — create/use the separate webhook secret configured in Razorpay Dashboard

For SMS, the configured MSG91 template should support variables `VAR1` appointment reference, `VAR2` date, `VAR3` time, `VAR4` fee. The approved template text must match the registered DLT template. For WhatsApp, the approved template must contain five body placeholders in this order: patient name, appointment reference, date, time, fee. Patients should consent to these messages. Provider “accepted” is not proof of final delivery; verify the receiving device and provider logs.

## Deploy Edge Functions

Run PowerShell in the project root (folder containing `index.html` and `supabase/`):

```powershell
npx supabase login
npx supabase link --project-ref nestxckkpbyfjpwsuiqu
npx supabase functions deploy create-appointment-razorpay-order --no-verify-jwt
npx supabase functions deploy verify-appointment-razorpay-payment --no-verify-jwt
npx supabase functions deploy book-appointment --no-verify-jwt
npx supabase functions deploy razorpay-webhook --no-verify-jwt
```

Use the actual project reference if it differs. Verify function deployment with `npx supabase functions list` or Supabase Dashboard → Edge Functions.

## Razorpay webhook configuration

In the Razorpay **Test Mode** dashboard, set webhook URL to:

`https://YOUR_PROJECT_REF.supabase.co/functions/v1/razorpay-webhook`

Subscribe to `payment.captured`, `order.paid`, and `payment.failed`. Set the matching webhook secret as `RAZORPAY_WEBHOOK_SECRET` in Supabase. Keep Razorpay API secret and webhook secret separate unless deliberately configured otherwise.

## Appointment flow expected behavior

1. Customer chooses a doctor, future date and available 30-minute slot, then enters name, phone and email.
2. Backend checks the slot and reserves it temporarily for 15 minutes while payment is pending.
3. Razorpay checkout opens for ₹5 in TEST ONLY mode.
4. The verification function validates the signature and checks the payment directly with Razorpay.
5. Only verified payment changes appointment to `Confirmed` and `Paid`. The slot then disappears from availability for all customers.
6. Payment failure/cancellation must never show a Paid success state. Pending reservations expire according to `payment_expires_at` and availability logic.
7. The verified flow attempts configured email, MSG91 SMS and WhatsApp template delivery. The email includes appointment reference, payment ID, date/time in IST, a WhatsApp link and a QR code for the clinic's WhatsApp contact.
8. A valid Razorpay webhook can also reconcile a payment if the customer closes the browser before the frontend verification call finishes.

## Test and deploy

Follow `TEST_CASES_AND_BIGROCK_DEPLOYMENT.md` and execute the cases before public launch. Confirm Supabase database records, Razorpay Test Mode transactions, notification-provider logs and the receiving test device.

## BigRock hosting summary

1. Keep a backup of the current published website.
2. In BigRock, open the hosting plan's cPanel → File Manager → target domain's `public_html`.
3. Upload the reviewed root `index.html` and any required static assets. Keep `supabase/` in the local source folder for CLI deployment; Supabase Edge Functions are not run by BigRock.
4. Enable SSL and test the website using HTTPS. Prefer a staging subdomain first.
5. If the domain currently points to Netlify, do not change DNS/nameservers until the BigRock version and HTTPS are verified and you have a rollback plan.
6. Test the BigRock-hosted page calls the existing Supabase project correctly. Keep only the Supabase publishable/anon key in frontend code; never expose service-role or Razorpay secret keys.
7. Do not publish the ₹5 TEST fee. Restore the approved live fee in all code paths and repeat the payment tests before switching to live Razorpay keys.

## Security and release reminders

- Never manually mark an appointment Paid to bypass payment verification.
- Never expose `SUPABASE_SERVICE_ROLE_KEY`, `RAZORPAY_KEY_SECRET`, MSG91 auth key, Resend API key or WhatsApp access token in browser files.
- Rotate any secret that has been accidentally published or shared.
- Do not claim SMS/email/WhatsApp is active until credentials/templates are configured and a test message is actually received.
