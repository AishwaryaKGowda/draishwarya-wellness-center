-- Store explicit customer consent before sending WhatsApp messages. Additive migration only.
alter table public.orders add column if not exists whatsapp_opt_in boolean not null default false;
alter table public.appointments add column if not exists whatsapp_opt_in boolean not null default false;

comment on column public.orders.whatsapp_opt_in is 'Customer explicitly opted in to WhatsApp order updates at checkout.';
comment on column public.appointments.whatsapp_opt_in is 'Customer explicitly opted in to WhatsApp appointment confirmations when booking.';
