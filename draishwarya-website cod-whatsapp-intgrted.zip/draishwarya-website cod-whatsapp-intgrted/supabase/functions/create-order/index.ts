
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const reply = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: {
      ...cors,
      "Content-Type": "application/json",
    },
  });

const escapeHtml = (value: unknown): string =>
  String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  }[char] ?? char));

Deno.serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: cors });
  }

  if (req.method !== "POST") {
    return reply({ error: "Method not allowed" }, 405);
  }

  const url = Deno.env.get("SUPABASE_URL");
  const anon = Deno.env.get("SUPABASE_ANON_KEY");
  const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

  if (!url || !anon || !service) {
    return reply({ error: "Server configuration missing" }, 500);
  }

  const authHeader = req.headers.get("Authorization");

  if (!authHeader?.startsWith("Bearer ")) {
    return reply({ error: "Sign in before placing an order" }, 401);
  }

  // Validate the signed-in customer.
  const userClient = createClient(url, anon, {
    global: {
      headers: { Authorization: authHeader },
    },
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });

  const { data: userData, error: userError } =
    await userClient.auth.getUser();

  const user = userData?.user;

  if (userError || !user) {
    return reply({ error: "Invalid or expired session" }, 401);
  }

  let body: Record<string, any>;

  try {
    body = await req.json();
  } catch {
    return reply({ error: "Invalid JSON body" }, 400);
  }

  const name = String(body.name ?? "").trim();
  const phone = String(body.phone ?? "").replace(/\D/g, "");
  const addr = String(body.addr ?? "").trim();
  const note = String(body.note ?? "").trim().slice(0, 1000);
  const pay = String(body.pay ?? "cod").toLowerCase();
  const items = body.items;

  if (
    name.length < 2 ||
    !/^[6-9]\d{9}$/.test(phone) ||
    addr.length < 8
  ) {
    return reply(
      {
        error:
          "Provide a valid name, 10-digit Indian mobile number, and full address",
      },
      400,
    );
  }

  if (pay !== "cod") {
    return reply(
      { error: "This endpoint currently supports Cash on Delivery only" },
      400,
    );
  }

  if (!Array.isArray(items) || items.length < 1 || items.length > 50) {
    return reply({ error: "Cart is empty or invalid" }, 400);
  }

  const normalized = new Map<number, number>();

  for (const item of items) {
    const id = Number(item?.id);
    const qty = Number(item?.q);

    if (
      !Number.isSafeInteger(id) ||
      id <= 0 ||
      !Number.isSafeInteger(qty) ||
      qty < 1 ||
      qty > 25
    ) {
      return reply({ error: "Invalid product or quantity" }, 400);
    }

    normalized.set(id, (normalized.get(id) ?? 0) + qty);
  }

  const admin = createClient(url, service, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });

  // Validate products and prices from the database.
  const ids = [...normalized.keys()];

  const { data: products, error: productError } = await admin
    .from("products")
    .select("id,name,cat,size,price,stock_quantity,active")
    .in("id", ids);

  if (productError) {
    console.error("Product validation failed:", productError.message);
    return reply({ error: "Could not validate products" }, 500);
  }

  if (!products || products.length !== ids.length) {
    return reply({ error: "One or more products are unavailable" }, 400);
  }

  let total = 0;

  const snapshots: Array<{
    id: number;
    name: string;
    q: number;
    size: string | null;
    price: number;
  }> = [];

  for (const product of products) {
    const qty = normalized.get(Number(product.id))!;

    if (!product.active) {
      return reply(
        { error: `Product ${product.name} is unavailable` },
        400,
      );
    }

    if (Number(product.stock_quantity) < qty) {
      return reply(
        { error: `Insufficient stock for ${product.name}` },
        400,
      );
    }

    const price = Number(product.price);

    if (!Number.isFinite(price) || price < 0) {
      return reply({ error: "Invalid product price in database" }, 500);
    }

    total += price * qty;

    snapshots.push({
      id: Number(product.id),
      name: product.name,
      q: qty,
      size: product.size ?? null,
      price,
    });
  }

  total = Math.round(total * 100) / 100;

  // Load the authenticated customer's saved profile and email.
  const { data: profile, error: profileError } = await admin
    .from("profiles")
    .select("id,name,email,phone,addr")
    .eq("id", user.id)
    .maybeSingle();

  if (profileError) {
    console.error("Profile lookup failed:", profileError.message);
    return reply({ error: "Could not load customer profile" }, 500);
  }

  if (!profile) {
    return reply(
      {
        error:
          "Customer profile is missing. Please sign out and sign in again.",
      },
      409,
    );
  }

  // Save the COD order before sending notifications.
  const { data: order, error: orderError } = await admin
    .from("orders")
    .insert({
      uid: user.id,
      name,
      phone,
      addr,
      total,
      status: "Pending",
      pay: "cod",
      payment_status: "Pending",
      note,
      items: snapshots,
      currency: "INR",
      shipping_fee: 0,
      whatsapp_opt_in: body.whatsapp_opt_in === true,
    })
    .select(
      "id,uid,name,phone,addr,total,date,status,pay,payment_status,note,items,currency,shipping_fee",
    )
    .single();

  if (orderError || !order) {
    console.error("Order creation failed:", orderError?.message);
    return reply({ error: "Order could not be saved" }, 500);
  }

  // Update saved customer contact information.
  const { error: profileUpdateError } = await admin
    .from("profiles")
    .update({
      phone,
      addr,
      updated_at: new Date().toISOString(),
    })
    .eq("id", user.id);

  if (profileUpdateError) {
    console.error(
      "Profile contact update failed:",
      profileUpdateError.message,
    );
  }

  // --------------------------------------------------
  // 1. MSG91 COD SMS
  // --------------------------------------------------
  let smsStatus = "not_configured";

  const msg91AuthKey = Deno.env.get("MSG91_AUTH_KEY");
  const msg91TemplateId = Deno.env.get("MSG91_COD_TEMPLATE_ID");

  if (msg91AuthKey && msg91TemplateId) {
    try {
      const smsResponse = await fetch(
        "https://control.msg91.com/api/v5/flow",
        {
          method: "POST",
          headers: {
            authkey: msg91AuthKey,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            template_id: msg91TemplateId,
            recipients: [
              {
                mobiles: `91${phone}`,
                VAR1: String(order.id),
              },
            ],
          }),
        },
      );

      const responseText = await smsResponse.text();

      if (smsResponse.ok) {
        smsStatus = "accepted";
        console.log("MSG91 accepted COD SMS:", order.id);
      } else {
        smsStatus = "failed";
        console.error(
          "MSG91 request failed:",
          smsResponse.status,
          responseText,
        );
      }
    } catch (error) {
      smsStatus = "failed";
      console.error("MSG91 SMS request error:", error);
    }
  }

  // --------------------------------------------------
  // 2. WhatsApp COD confirmation (explicit opt-in only)
  // --------------------------------------------------
  let whatsappStatus = "not_configured_or_not_opted_in";

  const waToken = Deno.env.get("WHATSAPP_ACCESS_TOKEN");
  const waPhoneId = Deno.env.get("WHATSAPP_PHONE_NUMBER_ID");
  const waTemplate = Deno.env.get("WHATSAPP_COD_TEMPLATE");

  if (body.whatsapp_opt_in === true && waToken && waPhoneId && waTemplate) {
    const digits = phone.replace(/\D/g, "");
    const waTo = digits.length === 10 ? `91${digits}` : digits;

    if (waTo.length >= 11 && waTo.length <= 15) {
      try {
        const waResponse = await fetch(
          `https://graph.facebook.com/v20.0/${waPhoneId}/messages`,
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${waToken}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              messaging_product: "whatsapp",
              to: waTo,
              type: "template",
              template: {
                name: waTemplate,
                language: {
                  code: Deno.env.get("WHATSAPP_TEMPLATE_LANG") || "en",
                },
                components: [
                  {
                    type: "body",
                    parameters: [
                      { type: "text", text: String(order.name || name) },
                      { type: "text", text: String(order.id) },
                      { type: "text", text: `₹${total.toFixed(2)}` },
                      { type: "text", text: "Cash on Delivery" },
                    ],
                  },
                ],
              },
            }),
          },
        );

        const responseText = await waResponse.text();
        whatsappStatus = waResponse.ok ? "accepted" : "failed";

        if (!waResponse.ok) {
          console.error(
            "WhatsApp COD confirmation failed:",
            waResponse.status,
            responseText,
          );
        }
      } catch (error) {
        whatsappStatus = "failed";
        console.error("WhatsApp COD confirmation error:", error);
      }
    } else {
      whatsappStatus = "invalid_customer_phone";
    }
  }

  // --------------------------------------------------
  // 3. Resend COD order confirmation email
  // --------------------------------------------------
  let emailStatus = "not_configured";

  const resendApiKey = Deno.env.get("RESEND_API_KEY");
  const fromEmail = Deno.env.get("APPOINTMENT_FROM_EMAIL");
  const customerEmail = String(profile.email ?? "").trim();

  if (
    resendApiKey &&
    fromEmail &&
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customerEmail)
  ) {
    const itemRows = snapshots
      .map(
        (item) => `
          <tr>
            <td style="padding:8px;border-bottom:1px solid #eee">
              ${escapeHtml(item.name)}
            </td>
            <td style="padding:8px;border-bottom:1px solid #eee;text-align:center">
              ${item.q}
            </td>
            <td style="padding:8px;border-bottom:1px solid #eee;text-align:right">
              ₹${(item.price * item.q).toFixed(2)}
            </td>
          </tr>
        `,
      )
      .join("");

    try {
      const emailResponse = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${resendApiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          from: `Dr. Aishwarya Wellness Center <${fromEmail}>`,
          to: [customerEmail],
          subject: `COD order received — Order #${order.id}`,
          html: `
            <div style="font-family:Arial,sans-serif;max-width:620px;margin:auto;padding:24px;color:#222">
              <h2 style="color:#87651c">Thank you for your order!</h2>
              <p>Hello ${escapeHtml(name)},</p>
              <p>
                We have received your Cash on Delivery order.
                Your order is saved and is currently pending processing.
              </p>
              <p>
                <strong>Order reference:</strong> #${escapeHtml(order.id)}<br>
                <strong>Payment method:</strong> Cash on Delivery<br>
                <strong>Order total:</strong> ₹${total.toFixed(2)}
              </p>
              <table style="width:100%;border-collapse:collapse;margin:18px 0">
                <thead>
                  <tr>
                    <th style="text-align:left;padding:8px;border-bottom:2px solid #ddd">Product</th>
                    <th style="text-align:center;padding:8px;border-bottom:2px solid #ddd">Qty</th>
                    <th style="text-align:right;padding:8px;border-bottom:2px solid #ddd">Amount</th>
                  </tr>
                </thead>
                <tbody>${itemRows}</tbody>
              </table>
              <p>
                <strong>Delivery address:</strong><br>
                ${escapeHtml(addr)}
              </p>
              <p>We will contact you with further updates.</p>
              <p>Dr. Aishwarya Wellness Center</p>
            </div>
          `,
        }),
      });

      const responseText = await emailResponse.text();
      emailStatus = emailResponse.ok ? "accepted" : "failed";

      if (emailResponse.ok) {
        console.log("Resend accepted COD order email:", order.id);
      } else {
        console.error(
          "Resend COD email failed:",
          emailResponse.status,
          responseText,
        );
      }
    } catch (error) {
      emailStatus = "failed";
      console.error("Resend COD email request error:", error);
    }
  } else if (!resendApiKey || !fromEmail) {
    console.error(
      "COD email not configured: check RESEND_API_KEY and APPOINTMENT_FROM_EMAIL",
    );
  } else {
    emailStatus = "customer_email_missing";
    console.error(
      "COD email skipped: profile has no valid email address",
    );
  }

  // Preserve the response fields used by the existing frontend.
  return reply(
    { order, smsStatus, whatsappStatus, emailStatus },
    201,
  );
});
