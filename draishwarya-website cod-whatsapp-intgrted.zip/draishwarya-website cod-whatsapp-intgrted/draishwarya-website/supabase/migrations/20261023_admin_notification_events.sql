-- Admin in-app notification events for customer signups, orders, payments and COD collection.
-- Additive only: does not drop tables or existing records.

alter table public.notifications
  add column if not exists event_type text not null default 'message',
  add column if not exists is_read boolean not null default false,
  add column if not exists metadata jsonb not null default '{}'::jsonb;

create index if not exists notifications_created_at_desc_idx on public.notifications (created_at desc);
create index if not exists notifications_unread_idx on public.notifications (is_read, created_at desc);

alter table public.notifications enable row level security;
drop policy if exists "Admins can update notification read state" on public.notifications;
create policy "Admins can update notification read state" on public.notifications
for update to authenticated
using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'))
with check (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'));

create or replace function public.dawc_notify_admin_customer_signup()
returns trigger
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  v_email text := coalesce(new.email, 'Email not provided');
  v_name text := coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', 'New customer');
begin
  insert into public.notifications (user_id, channel, recipient, subject, message, status, event_type, metadata)
  values (new.id, 'admin', 'admin', 'New customer registered',
          v_name || ' registered (' || v_email || ').', 'unread', 'customer_registered',
          jsonb_build_object('customer_id', new.id, 'email', new.email));
  return new;
exception when others then
  -- Do not block signup if notification logging has a temporary issue.
  raise warning 'DAWC customer signup notification failed: %', SQLERRM;
  return new;
end;
$$;

drop trigger if exists dawc_notify_admin_customer_signup on auth.users;
create trigger dawc_notify_admin_customer_signup
after insert on auth.users
for each row execute function public.dawc_notify_admin_customer_signup();

create or replace function public.dawc_notify_admin_order_events()
returns trigger
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  j_new jsonb := to_jsonb(new);
  j_old jsonb := case when tg_op = 'UPDATE' then to_jsonb(old) else '{}'::jsonb end;
  v_order_id text := coalesce(j_new->>'id', 'unknown');
  v_uid_text text := coalesce(j_new->>'uid', j_new->>'user_id', '');
  v_uid uuid := null;
  v_name text := coalesce(j_new->>'name', 'Customer');
  v_total text := coalesce(j_new->>'total', '0');
  v_pay text := coalesce(j_new->>'pay', j_new->>'payment_gateway', 'unknown');
  v_status text := coalesce(j_new->>'payment_status', 'Pending');
  v_event text := null;
  v_subject text := null;
  v_message text := null;
begin
  if v_uid_text ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then
    v_uid := v_uid_text::uuid;
  end if;

  if tg_op = 'INSERT' then
    v_event := 'order_placed';
    v_subject := 'New order placed';
    v_message := 'Order ' || v_order_id || ' was placed by ' || v_name || '. Total: ₹' || v_total || '. Method: ' || v_pay || '.';
  elsif coalesce(j_old->>'balance_due','0')::numeric > 0 and coalesce(j_new->>'balance_due','0')::numeric <= 0
        and lower(coalesce(j_new->>'payment_status','')) = 'paid'
        and coalesce(j_old->>'payment_status','') is distinct from coalesce(j_new->>'payment_status','') then
    v_event := 'cod_collected';
    v_subject := 'COD collection recorded';
    v_message := 'The outstanding balance for order ' || v_order_id || ' was marked as collected. Verify cash receipt in the order record.';
  elsif coalesce(j_old->>'payment_status','') is distinct from coalesce(j_new->>'payment_status','') then
    if lower(v_status) in ('paid','advance paid','captured','success','successful') then
      v_event := 'payment_success'; v_subject := 'Payment status updated';
      v_message := 'Order ' || v_order_id || ' payment status is now ' || v_status || '. Total: ₹' || v_total || '.';
    elsif lower(v_status) in ('failed','failure') then
      v_event := 'payment_failed'; v_subject := 'Payment failed';
      v_message := 'Order ' || v_order_id || ' payment status is ' || v_status || '. Do not mark as paid unless verified.';
    else
      v_event := 'payment_status_changed'; v_subject := 'Payment status changed';
      v_message := 'Order ' || v_order_id || ' payment status changed to ' || v_status || '.';
    end if;
  end if;

  if v_event is not null then
    insert into public.notifications (user_id, order_id, channel, recipient, subject, message, status, event_type, metadata)
    values (v_uid, v_order_id, 'admin', 'admin', v_subject, v_message, 'unread', v_event,
            jsonb_build_object('order_id', v_order_id, 'customer_name', v_name, 'total', v_total, 'payment_method', v_pay, 'payment_status', v_status));
  end if;
  return new;
exception when others then
  -- Do not block order/payment state changes if notification logging has a temporary issue.
  raise warning 'DAWC order notification failed: %', SQLERRM;
  return new;
end;
$$;

drop trigger if exists dawc_notify_admin_order_events on public.orders;
create trigger dawc_notify_admin_order_events
after insert or update on public.orders
for each row execute function public.dawc_notify_admin_order_events();

-- Existing appointment-status notification logging remains available in the website.
-- These are in-app admin records only; they do not claim email/SMS/WhatsApp was delivered.
