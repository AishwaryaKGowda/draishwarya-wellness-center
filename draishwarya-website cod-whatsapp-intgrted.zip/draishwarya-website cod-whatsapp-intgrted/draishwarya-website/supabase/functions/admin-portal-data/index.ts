import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status, headers: { ...corsHeaders, "Content-Type": "application/json" },
});
const dateValue = (row: any) => {
  const value = row?.date || row?.created_at || row?.created || row?.updated_at || "";
  const parsed = Date.parse(value);
  return Number.isFinite(parsed) ? parsed : 0;
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  const url = Deno.env.get("SUPABASE_URL");
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !anonKey || !serviceKey) return json({ error: "Server Supabase secrets are missing." }, 500);

  const authorization = req.headers.get("Authorization") || "";
  if (!authorization.startsWith("Bearer ")) return json({ error: "Sign in as an administrator first." }, 401);

  const userClient = createClient(url, anonKey, {
    global: { headers: { Authorization: authorization } },
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const adminClient = createClient(url, serviceKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  const { data: userResult, error: userError } = await userClient.auth.getUser();
  const caller = userResult?.user;
  if (userError || !caller) return json({ error: "Your session is invalid or expired. Sign in again." }, 401);
  const { data: callerProfile, error: profileError } = await adminClient
    .from("profiles").select("role").eq("id", caller.id).maybeSingle();
  if (profileError || callerProfile?.role !== "admin") {
    return json({ error: "Admin authorization required. The signed-in user's profiles.role must be admin." }, 403);
  }

  let body: any;
  try { body = await req.json(); } catch { return json({ error: "Invalid JSON body." }, 400); }
  const action = String(body?.action || "list");

  if (action === "list") {
    const [profilesResult, ordersResult] = await Promise.all([
      adminClient.from("profiles").select("*").limit(5000),
      adminClient.from("orders").select("*").limit(2000),
    ]);
    if (profilesResult.error) return json({ error: "Could not load customer profiles.", details: profilesResult.error.message }, 500);
    if (ordersResult.error) return json({ error: "Could not load orders.", details: ordersResult.error.message }, 500);

    // Auth is the source of truth for registrations and last sign-in timestamps.
    // The service-role key stays on the server; this endpoint is available only to verified admins.
    const authUsers: any[] = [];
    for (let page = 1; page <= 100; page++) {
      const { data, error } = await adminClient.auth.admin.listUsers({ page, perPage: 1000 });
      if (error) return json({ error: "Could not load registered Auth users.", details: error.message }, 500);
      const batch = data?.users || [];
      authUsers.push(...batch);
      if (batch.length < 1000) break;
    }

    const profiles = profilesResult.data || [];
    const byId = new Map<string, any>(profiles.map((p: any) => [String(p.id), p]));
    const customers = authUsers.map((authUser: any) => {
      const profile = byId.get(String(authUser.id)) || {};
      const metadata = authUser.user_metadata || {};
      const role = String(profile.role || metadata.role || "customer").toLowerCase();
      if (role === "admin" || role === "doctor") return null;
      return {
        id: authUser.id,
        name: profile.name || profile.full_name || metadata.name || authUser.email?.split("@")[0] || "Customer",
        email: profile.email || authUser.email || "",
        phone: profile.phone || metadata.phone || "",
        addr: profile.addr || "",
        role,
        created_at: authUser.created_at || profile.created_at || profile.created || null,
        last_sign_in_at: authUser.last_sign_in_at || null,
      };
    }).filter(Boolean);

    // Include a profile-only customer record if it is not represented by the Auth page result.
    const authIds = new Set(authUsers.map((u: any) => String(u.id)));
    for (const profile of profiles) {
      const id = String(profile.id || "");
      if (!id || authIds.has(id) || String(profile.role || "customer").toLowerCase() !== "customer") continue;
      customers.push({
        id, name: profile.name || profile.full_name || "Customer", email: profile.email || "",
        phone: profile.phone || "", addr: profile.addr || "", role: "customer",
        created_at: profile.created_at || profile.created || null, last_sign_in_at: null,
      });
    }

    const orders = (ordersResult.data || []).sort((a: any, b: any) => dateValue(b) - dateValue(a));
    return json({ ok: true, orders, customers, order_count: orders.length, customer_count: customers.length });
  }

  if (action === "update_order") {
    const orderId = String(body?.order_id || "").trim();
    const updateAction = String(body?.update_action || "");
    if (!orderId) return json({ error: "Order ID is required." }, 400);

    const { data: order, error: loadError } = await adminClient.from("orders")
      .select("*").eq("id", orderId).maybeSingle();
    if (loadError) return json({ error: "Could not load this order.", details: loadError.message }, 500);
    if (!order) return json({ error: "Order not found." }, 404);

    let patch: Record<string, unknown>;
    if (updateAction === "status") {
      const status = String(body?.value || "");
      const allowed = ["Pending", "Placed", "Confirmed", "Processing", "Shipped", "Delivered", "Cancelled"];
      if (!allowed.includes(status)) return json({ error: "Invalid order status." }, 400);
      patch = { status, updated_at: new Date().toISOString() };
    } else if (updateAction === "mark_cod_collected") {
      const method = String(order.pay || order.payment_gateway || "").toLowerCase();
      if (!method.includes("cod") && method !== "cash on delivery") {
        return json({ error: "Only COD or advance-plus-COD orders can be marked as COD collected." }, 400);
      }
      const total = Math.max(0, Number(order.total || 0));
      const advance = Math.max(0, Number(order.advance_amount || 0));
      const storedDue = Number(order.balance_due || 0);
      const due = String(order.payment_status || "").toLowerCase() === "paid"
        ? 0
        : storedDue > 0
          ? storedDue
          : Math.max(0, total - advance);
      if (due <= 0 || String(order.payment_status || "").toLowerCase() === "paid") {
        return json({ error: "This order has no outstanding COD balance." }, 409);
      }
      patch = {
        advance_amount: total,
        balance_due: 0,
        payment_status: "Paid",
        payment_gateway: order.payment_gateway || (method.includes("advance") ? "razorpay+cod" : "cod"),
        updated_at: new Date().toISOString(),
      };
    } else {
      return json({ error: "Unsupported order update action." }, 400);
    }

    const { data: updated, error: updateError } = await adminClient.from("orders")
      .update(patch).eq("id", orderId).select("*").single();
    if (updateError) return json({ error: "Order update failed.", details: updateError.message }, 500);
    return json({ ok: true, order: updated });
  }

  return json({ error: "Unsupported action." }, 400);
});
