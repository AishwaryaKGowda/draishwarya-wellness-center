
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const reply = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: {
      ...cors,
      "Content-Type": "application/json",
    },
  });

Deno.serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: cors });
  }

  if (req.method !== "POST") {
    return reply({ error: "Method not allowed" }, 405);
  }

  const url = Deno.env.get("SUPABASE_URL");
  const anon = Deno.env.get("SUPABASE_ANON_KEY");
  const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

  if (!url || !anon || !service) {
    return reply({ error: "Server configuration missing" }, 500);
  }

  const authHeader = req.headers.get("Authorization");

  if (!authHeader?.startsWith("Bearer ")) {
    return reply({ error: "Sign in before placing an order" }, 401);
  }

  // Validate the signed-in user. Never trust a UID from the request body.
  const userClient = createClient(url, anon, {
    global: {
      headers: { Authorization: authHeader },
    },
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });

  const { data: userData, error: userError } =
    await userClient.auth.getUser();

  const user = userData?.user;

  if (userError || !user) {
    return reply({ error: "Invalid or expired session" }, 401);
  }

  let body: Record<string, any>;

  try {
    body = await req.json();
  } catch {
    return reply({ error: "Invalid JSON body" }, 400);
  }

  const name = String(body.name ?? "").trim();
  const phone = String(body.phone ?? "").replace(/\D/g, "");
  const addr = String(body.addr ?? "").trim();
  const note = String(body.note ?? "").trim().slice(0, 1000);
  const pay = String(body.pay ?? "cod").toLowerCase();
  const items = body.items;

  if (
    name.length < 2 ||
    !/^[6-9]\d{9}$/.test(phone) ||
    addr.length < 8
  ) {
    return reply(
      {
        error:
          "Provide a valid name, 10-digit Indian mobile number, and full address",
      },
      400,
    );
  }

  if (pay !== "cod") {
    return reply(
      { error: "This endpoint currently supports Cash on Delivery only" },
      400,
    );
  }

  if (!Array.isArray(items) || items.length < 1 || items.length > 50) {
    return reply({ error: "Cart is empty or invalid" }, 400);
  }

  const normalized = new Map<number, number>();

  for (const item of items) {
    const id = Number(item?.id);
    const qty = Number(item?.q);

    if (
      !Number.isSafeInteger(id) ||
      id <= 0 ||
      !Number.isSafeInteger(qty) ||
      qty < 1 ||
      qty > 25
    ) {
      return reply({ error: "Invalid product or quantity" }, 400);
    }

    normalized.set(id, (normalized.get(id) ?? 0) + qty);
  }

  const admin = createClient(url, service, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });

  const ids = [...normalized.keys()];

  const { data: products, error: productError } = await admin
    .from("products")
    .select("id,name,cat,size,price,stock_quantity,active")
    .in("id", ids);

  if (productError) {
    console.error("Product validation failed:", productError.message);
    return reply({ error: "Could not validate products" }, 500);
  }

  if (!products || products.length !== ids.length) {
    return reply(
      { error: "One or more products are unavailable" },
      400,
    );
  }

  let total = 0;

  const snapshots: Array<{
    id: number;
    name: string;
    q: number;
    size: string | null;
    price: number;
  }> = [];

  for (const product of products) {
    const qty = normalized.get(Number(product.id))!;

    if (!product.active) {
      return reply(
        { error: `Product ${product.name} is unavailable` },
        400,
      );
    }

    if (Number(product.stock_quantity) < qty) {
      return reply(
        { error: `Insufficient stock for ${product.name}` },
        400,
      );
    }

    const price = Number(product.price);

    if (!Number.isFinite(price) || price < 0) {
      return reply(
        { error: "Invalid product price in database" },
        500,
      );
    }

    total += price * qty;

    snapshots.push({
      id: Number(product.id),
      name: product.name,
      q: qty,
      size: product.size ?? null,
      price,
    });
  }

  total = Math.round(total * 100) / 100;

  const { data: profile, error: profileError } = await admin
    .from("profiles")
    .select("id,name,email,phone,addr")
    .eq("id", user.id)
    .maybeSingle();

  if (profileError) {
    console.error("Profile lookup failed:", profileError.message);
    return reply({ error: "Could not load customer profile" }, 500);
  }

  if (!profile) {
    return reply(
      {
        error:
          "Customer profile is missing. Please sign out and sign in again.",
      },
      409,
    );
  }

  // Create the COD order first.
  const { data: order, error: orderError } = await admin
    .from("orders")
    .insert({
      uid: user.id,
      name,
      phone,
      addr,
      total,
      status: "Pending",
      pay: "cod",
      payment_status: "Pending",
      note,
      items: snapshots,
      currency: "INR",
      shipping_fee: 0,
    })
    .select(
      "id,uid,name,phone,addr,total,date,status,pay,payment_status,note,items,currency,shipping_fee",
    )
    .single();

  if (orderError || !order) {
    console.error("Order creation failed:", orderError?.message);
    return reply({ error: "Order could not be saved" }, 500);
  }

  // Update the customer's saved contact details.
  const { error: profileUpdateError } = await admin
    .from("profiles")
    .update({
      phone,
      addr,
      updated_at: new Date().toISOString(),
    })
    .eq("id", user.id);

  if (profileUpdateError) {
    console.error(
      "Profile contact update failed:",
      profileUpdateError.message,
    );
  }

  // Send the COD confirmation SMS after order creation.
  // An SMS failure must not undo the order.
  let smsStatus = "not_configured";

  const msg91AuthKey = Deno.env.get("MSG91_AUTH_KEY");
  const msg91TemplateId = Deno.env.get("MSG91_COD_TEMPLATE_ID");

  if (msg91AuthKey && msg91TemplateId) {
    try {
      const smsResponse = await fetch(
        "https://control.msg91.com/api/v5/flow",
        {
          method: "POST",
          headers: {
            authkey: msg91AuthKey,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            template_id: msg91TemplateId,
            recipients: [
              {
                mobiles: `91${phone}`,
                VAR1: String(order.id),
              },
            ],
          }),
        },
      );

      const responseText = await smsResponse.text();

      if (smsResponse.ok) {
        smsStatus = "accepted";
        console.log(
          "MSG91 accepted COD SMS for order:",
          String(order.id),
        );
      } else {
        smsStatus = "failed";
        console.error(
          "MSG91 request failed:",
          smsResponse.status,
          responseText,
        );
      }
    } catch (error) {
      smsStatus = "failed";
      console.error("MSG91 SMS request error:", error);
    }
  } else {
    console.error(
      "MSG91_AUTH_KEY or MSG91_COD_TEMPLATE_ID is missing",
    );
  }

  // Keep the existing order response available to the frontend.
  return reply({ order, smsStatus }, 201);
});
