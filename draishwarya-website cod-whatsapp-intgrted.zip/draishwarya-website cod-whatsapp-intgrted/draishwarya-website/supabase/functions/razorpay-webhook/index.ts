import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const reply=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers:{"Content-Type":"application/json"}});
const hex=(b:ArrayBuffer)=>Array.from(new Uint8Array(b)).map(x=>x.toString(16).padStart(2,"0")).join("");
async function hmac(secret:string,msg:string){const k=await crypto.subtle.importKey("raw",new TextEncoder().encode(secret),{name:"HMAC",hash:"SHA-256"},false,["sign"]);return hex(await crypto.subtle.sign("HMAC",k,new TextEncoder().encode(msg)));}
function safeEqual(a:string,b:string){if(a.length!==b.length)return false;let n=0;for(let i=0;i<a.length;i++)n|=a.charCodeAt(i)^b.charCodeAt(i);return n===0;}
Deno.serve(async(req)=>{
 if(req.method!=="POST")return reply({error:"Method not allowed"},405);
 const url=Deno.env.get("SUPABASE_URL"),service=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"),secret=Deno.env.get("RAZORPAY_WEBHOOK_SECRET");
 if(!url||!service||!secret)return reply({error:"Webhook is not configured"},500);
 const raw=await req.text(),signature=req.headers.get("x-razorpay-signature")||"";if(!signature||!safeEqual(await hmac(secret,raw),signature))return reply({error:"Invalid webhook signature"},401);
 let event:any;try{event=JSON.parse(raw)}catch{return reply({error:"Invalid JSON"},400)}
 const entity=event?.payload?.payment?.entity;if(!entity?.id||!entity?.order_id)return reply({received:true,ignored:true});
 const admin=createClient(url,service,{auth:{persistSession:false,autoRefreshToken:false}});const now=new Date().toISOString();
 if(event.event==="payment.captured"||event.event==="order.paid"){
  const {data:appt}=await admin.from("appointments").select("id,patient,phone,email,svc,date,time,doc,fee,payment_status,razorpay_payment_id").eq("razorpay_order_id",entity.order_id).maybeSingle();
  if(appt){
   if(entity.currency!=="INR"||Number(entity.amount)!==500)return reply({error:"Appointment webhook amount mismatch"},400);
   if(appt.payment_status!=="Paid"){
    const {data:updated}=await admin.from("appointments").update({status:"Confirmed",payment_status:"Paid",razorpay_payment_id:entity.id,updated_at:now}).eq("id",appt.id).eq("payment_status","Pending").select("id").maybeSingle();
    if(updated){
     const resend=Deno.env.get("RESEND_API_KEY"),from=Deno.env.get("APPOINTMENT_FROM_EMAIL");
     if(resend&&from&&/^\S+@\S+\.\S+$/.test(String(appt.email||""))){try{await fetch("https://api.resend.com/emails",{method:"POST",headers:{Authorization:`Bearer ${resend}`,"Content-Type":"application/json"},body:JSON.stringify({from:`Dr. Aishwarya Wellness Center <${from}>`,to:[appt.email],subject:`Appointment confirmed — Reference #${appt.id}`,html:`<h2>Payment received</h2><p>Hello ${String(appt.patient||"Patient").replace(/[&<>]/g,"")}, your ₹5 TEST appointment payment is confirmed.</p><p>Appointment #${appt.id}<br>Date: ${String(appt.date)} (IST)<br>Time: ${String(appt.time).slice(0,5)} (IST)</p><p>Your selected slot is now confirmed and unavailable to other customers.</p><p><a href="https://wa.me/918088155724">Contact the clinic on WhatsApp: +91 80881 55724</a></p><p><a href="https://wa.me/918088155724"><img alt="WhatsApp contact QR code" width="150" height="150" src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=https%3A%2F%2Fwa.me%2F918088155724"></a></p>`})});}catch(e){console.error("Webhook appointment email failed",e);}}
     const waToken=Deno.env.get("WHATSAPP_ACCESS_TOKEN"),waPhoneId=Deno.env.get("WHATSAPP_PHONE_NUMBER_ID");
     if(waToken&&waPhoneId&&appt.phone&&Deno.env.get("WHATSAPP_APPOINTMENT_TEMPLATE")){let to=String(appt.phone).replace(/\D/g,"");if(to.length===10)to="91"+to;try{const waResp=await fetch(`https://graph.facebook.com/v20.0/${waPhoneId}/messages`,{method:"POST",headers:{Authorization:`Bearer ${waToken}`,"Content-Type":"application/json"},body:JSON.stringify({messaging_product:"whatsapp",to,type:"template",template:{name:Deno.env.get("WHATSAPP_APPOINTMENT_TEMPLATE"),language:{code:Deno.env.get("WHATSAPP_TEMPLATE_LANG")||"en"},components:[{type:"body",parameters:[{type:"text",text:String(appt.patient)},{type:"text",text:String(appt.id)},{type:"text",text:String(appt.date)},{type:"text",text:String(appt.time).slice(0,5)},{type:"text",text:"5"}]}]}})});if(!waResp.ok)console.error("Webhook WhatsApp notification failed",waResp.status,await waResp.text());}catch(e){console.error("Webhook WhatsApp notification failed",e);}}
     const smsKey=Deno.env.get("MSG91_AUTH_KEY"),smsTemplate=Deno.env.get("MSG91_APPOINTMENT_TEMPLATE_ID"),smsPhone=String(appt.phone||"").replace(/\D/g,"");if(smsKey&&smsTemplate&&smsPhone){try{const smsResp=await fetch("https://control.msg91.com/api/v5/flow",{method:"POST",headers:{authkey:smsKey,"Content-Type":"application/json"},body:JSON.stringify({template_id:smsTemplate,recipients:[{mobiles:smsPhone.length===10?"91"+smsPhone:smsPhone,VAR1:String(appt.id),VAR2:String(appt.date),VAR3:String(appt.time).slice(0,5),VAR4:"5"}]})});if(!smsResp.ok)console.error("Webhook appointment SMS failed",smsResp.status,await smsResp.text());}catch(e){console.error("Webhook appointment SMS error",e);}}
    }
   }
   return reply({received:true,appointment_id:appt.id});
  }
  const {data:order}=await admin.from("orders").select("id,pay,payment_status,advance_amount,balance_due,razorpay_payment_id").eq("razorpay_order_id",entity.order_id).maybeSingle();
  if(order){const expected=Math.round(Number(order.advance_amount||order.total)*100);if(entity.currency!=="INR"||Number(entity.amount)!==expected)return reply({error:"Order webhook amount mismatch"},400);const status=order.pay==="advance_cod"&&Number(order.balance_due)>0?"Advance Paid":"Paid";if(order.payment_status!=="Paid"&&order.payment_status!=="Advance Paid")await admin.from("orders").update({status:"Confirmed",payment_status:status,razorpay_payment_id:entity.id,payment_gateway:"razorpay",updated_at:now}).eq("id",order.id).eq("razorpay_order_id",entity.order_id);return reply({received:true,order_id:order.id});}
 }
 if(event.event==="payment.failed"){
  await admin.from("appointments").update({payment_status:"Failed",updated_at:now}).eq("razorpay_order_id",entity.order_id).eq("payment_status","Pending");
  await admin.from("orders").update({payment_status:"Failed",updated_at:now}).eq("razorpay_order_id",entity.order_id).eq("payment_status","Pending");
 }
 return reply({received:true});
});
