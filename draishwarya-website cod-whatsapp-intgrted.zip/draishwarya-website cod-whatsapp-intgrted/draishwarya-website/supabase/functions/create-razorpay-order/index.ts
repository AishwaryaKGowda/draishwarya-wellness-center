import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
const reply=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers:{...cors,"Content-Type":"application/json"}});
Deno.serve(async(req)=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:cors}); if(req.method!=="POST")return reply({error:"Method not allowed"},405);
 const url=Deno.env.get("SUPABASE_URL"),anon=Deno.env.get("SUPABASE_ANON_KEY"),service=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"),keyId=Deno.env.get("RAZORPAY_KEY_ID"),keySecret=Deno.env.get("RAZORPAY_KEY_SECRET");
 if(!url||!anon||!service||!keyId||!keySecret)return reply({error:"Server configuration missing. Check Supabase and Razorpay secrets."},500);
 const auth=req.headers.get("Authorization");if(!auth?.startsWith("Bearer "))return reply({error:"Sign in before placing an order"},401);
 const userClient=createClient(url,anon,{global:{headers:{Authorization:auth}},auth:{persistSession:false}});const {data:userData,error:userErr}=await userClient.auth.getUser();const user=userData?.user;if(userErr||!user)return reply({error:"Invalid or expired session"},401);
 let body:any;try{body=await req.json()}catch{return reply({error:"Invalid JSON body"},400)}
 const name=String(body?.name??"").trim(),phone=String(body?.phone??"").replace(/\D/g,""),addr=String(body?.addr??"").trim(),note=String(body?.note??"").trim().slice(0,1000),items=body?.items;
 if(name.length<2||!(/^[6-9]\d{9}$/.test(phone))||addr.length<8)return reply({error:"Provide a valid name, 10-digit Indian mobile number, and full address"},400);
 if(!Array.isArray(items)||items.length<1||items.length>50)return reply({error:"Cart is empty or invalid"},400);
 const quantities=new Map<number,number>();for(const item of items){const id=Number(item?.id),q=Number(item?.q);if(!Number.isSafeInteger(id)||id<=0||!Number.isSafeInteger(q)||q<1||q>25)return reply({error:"Invalid product or quantity"},400);quantities.set(id,(quantities.get(id)||0)+q)}
 const admin=createClient(url,service,{auth:{persistSession:false}});const ids=[...quantities.keys()];const {data:products,error:productsErr}=await admin.from("products").select("id,name,cat,size,price,stock_quantity,active").in("id",ids);
 if(productsErr)return reply({error:"Could not validate products",details:productsErr.message},500);if(!products||products.length!==ids.length)return reply({error:"One or more products are unavailable"},400);
 let total=0;const snapshots:any[]=[];for(const p of products){const q=quantities.get(Number(p.id))!;if(!p.active)return reply({error:`Product ${p.name} is unavailable`},400);if(Number(p.stock_quantity)<q)return reply({error:`Insufficient stock for ${p.name}`},400);const price=Number(p.price);if(!Number.isFinite(price)||price<0)return reply({error:"Invalid product price in database"},500);total+=price*q;snapshots.push({id:p.id,name:p.name,q,size:p.size,price})}
 total=Math.round(total*100);if(total<100)return reply({error:"Payment amount must be at least ₹1"},400);
 const {data:profile,error:profileErr}=await admin.from("profiles").select("id,name,email,phone,addr").eq("id",user.id).maybeSingle();if(profileErr)return reply({error:"Could not load customer profile",details:profileErr.message},500);if(!profile)return reply({error:"Customer profile is missing. Sign out and sign in again."},409);
 const paymentMode=String(body?.payment_mode||"razorpay")==="advance_cod"?"advance_cod":"razorpay";const advancePaise=paymentMode==="advance_cod"?Math.min(20000,total):total;
 const receipt=`dawc_${crypto.randomUUID().replaceAll("-","").slice(0,20)}`;
 const r=await fetch("https://api.razorpay.com/v1/orders",{method:"POST",headers:{Authorization:"Basic "+btoa(`${keyId}:${keySecret}`),"Content-Type":"application/json"},body:JSON.stringify({amount:advancePaise,currency:"INR",receipt,notes:{supabase_user_id:user.id,payment_mode:paymentMode}})});
 const rp=await r.json().catch(()=>({}));if(!r.ok||!rp.id)return reply({error:"Razorpay could not create the payment order",details:rp?.error?.description||`Razorpay HTTP ${r.status}`},502);
 const {data:order,error:orderErr}=await admin.from("orders").insert({uid:user.id,name,phone,addr,total:total/100,status:"Pending",pay:paymentMode,payment_status:"Pending",advance_amount:advancePaise/100,balance_due:Math.max(0,(total-advancePaise)/100),payment_gateway:"razorpay",note,items:snapshots,currency:"INR",shipping_fee:0,razorpay_order_id:rp.id}).select("id,uid,name,phone,addr,total,date,status,pay,payment_status,advance_amount,balance_due,note,items,currency,shipping_fee,razorpay_order_id").single();
 if(orderErr)return reply({error:"Razorpay order was created, but the website order could not be saved. Contact support before paying.",details:orderErr.message,razorpay_order_id:rp.id},500);
 await admin.from("profiles").update({phone,addr,updated_at:new Date().toISOString()}).eq("id",user.id);
 return reply({key_id:keyId,razorpay_order:{id:rp.id,amount:rp.amount,currency:rp.currency},order},201);
});
