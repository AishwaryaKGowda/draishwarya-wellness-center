import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json",
};

const allowedServices = new Set([
  "General Consultation",
  "Preventive Care",
  "Wellness & Lifestyle",
  "Follow-up Care",
]);

function reply(status: number, body: Record<string, unknown>) {
  return new Response(JSON.stringify(body), { status, headers: corsHeaders });
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return reply(405, { ok: false, error: "Method not allowed" });

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!supabaseUrl || !serviceRoleKey) {
      console.error("Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY Edge Function environment variables");
      return reply(500, { ok: false, error: "Backend is not configured. Check Supabase Edge Function environment variables." });
    }

    const payload = await req.json();
    const doctorEmail = String(payload?.doctor_email ?? "").trim().toLowerCase();
    const patient = String(payload?.patient ?? "").trim();
    const phone = String(payload?.phone ?? "").trim();
    const service = String(payload?.service ?? "").trim();
    const date = String(payload?.date ?? "").trim();
    const time = String(payload?.time ?? "").trim();
    const appointmentType = payload?.appointment_type === "online" ? "online" : "in_person";

    if (!doctorEmail) {
      return reply(400, { ok: false, error: "Please select a doctor." });
    }
    if (payload?.action !== "availability") {
      if (!patient || !phone || !service || !date || !time) {
        return reply(400, { ok: false, error: "Please provide doctor, name, phone, service, date and time." });
      }
      if (patient.length > 120) return reply(400, { ok: false, error: "Name is too long." });
      if (!/^\+?[0-9\s()\-]{10,20}$/.test(phone)) return reply(400, { ok: false, error: "Please enter a valid phone number." });
      if (!allowedServices.has(service)) return reply(400, { ok: false, error: "Invalid service selected." });
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) {
        return reply(400, { ok: false, error: "Invalid appointment date or time." });
      }
      const parsedDate = new Date(`${date}T00:00:00Z`);
      if (Number.isNaN(parsedDate.getTime()) || parsedDate.toISOString().slice(0, 10) !== date) {
        return reply(400, { ok: false, error: "Invalid appointment date." });
      }
      const today = new Date().toISOString().slice(0, 10);
      if (date < today) return reply(400, { ok: false, error: "Please choose today or a future date." });
    }

    const admin = createClient(supabaseUrl, serviceRoleKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    const { data: doctor, error: doctorError } = await admin
      .from("doctors")
      .select("id,email")
      .eq("email", doctorEmail)
      .eq("active", true)
      .maybeSingle();

    if (doctorError) {
      console.error("Doctor lookup failed:", doctorError.message);
      return reply(500, { ok: false, error: "Could not validate the selected doctor." });
    }
    if (!doctor) return reply(400, { ok: false, error: "This doctor is not active in the database. Check seed_doctors.sql and the doctor email." });

    // Availability lookup: only booked, non-cancelled slots are returned.
    if (payload?.action === "availability") {
      const availabilityDate = String(payload?.date ?? "").trim();
      if (!/^\d{4}-\d{2}-\d{2}$/.test(availabilityDate)) {
        return reply(400, { ok: false, error: "Choose a valid appointment date." });
      }
      const { data: existing, error: availabilityError } = await admin
        .from("appointments")
        .select("time,status,payment_status,payment_expires_at")
        .eq("doc", doctor.id)
        .eq("date", availabilityDate)
        .neq("status", "Cancelled");
      if (availabilityError) {
        console.error("Availability lookup failed:", availabilityError.message);
        return reply(500, { ok: false, error: "Could not load available slots. Please try again." });
      }
      const now = Date.now();
      const bookedSlots = (existing ?? []).filter((row: any) => row.status === "Confirmed" || row.payment_status === "Paid" || (row.payment_status === "Pending" && (!row.payment_expires_at || new Date(row.payment_expires_at).getTime() > now))).map((row: {time:string}) => String(row.time).slice(0,5));
      return reply(200, { ok: true, booked_slots: [...new Set(bookedSlots)] });
    }

    return reply(410, { ok: false, error: "Appointment booking now requires online payment. Use the create-appointment-razorpay-order function." });

    const { data: appointment, error: insertError } = await admin
      .from("appointments")
      .insert({
        user_id: null,
        doc: doctor.id,
        patient,
        phone,
        svc: service,
        date,
        time,
        status: "Confirmed",
        appointment_type: appointmentType,
      })
      .select("id")
      .single();

    if (insertError) {
      console.error("Appointment insert failed:", insertError.code, insertError.message);
      if (insertError.code === "23505") {
        return reply(409, { ok: false, error: "That doctor’s slot has already been booked. Please choose another time." });
      }
      return reply(500, { ok: false, error: "Could not save the appointment. Check the appointments table schema and Edge Function logs." });
    }

    return reply(200, { ok: true, id: appointment.id, status: "Confirmed", message: "Appointment confirmed." });
  } catch (error) {
    console.error("Unexpected booking error:", error instanceof Error ? error.message : error);
    return reply(400, { ok: false, error: "Invalid request. Please check the form and try again." });
  }
});
