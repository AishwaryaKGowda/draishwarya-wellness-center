import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status, headers: { ...corsHeaders, "Content-Type": "application/json" },
});
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  const url = Deno.env.get("SUPABASE_URL");
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !anonKey || !serviceKey) return json({ error: "Server environment is missing Supabase secrets." }, 500);
  const authHeader = req.headers.get("Authorization") || "";
  if (!authHeader.startsWith("Bearer ")) return json({ error: "Sign in as an administrator first." }, 401);
  const userClient = createClient(url, anonKey, { global: { headers: { Authorization: authHeader } }, auth: { persistSession: false } });
  const adminClient = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: { user }, error: authError } = await userClient.auth.getUser();
  if (authError || !user) return json({ error: "Your session is invalid or expired. Sign in again." }, 401);
  const { data: callerProfile, error: callerError } = await adminClient.from("profiles").select("role").eq("id", user.id).maybeSingle();
  if (callerError || callerProfile?.role !== "admin") return json({ error: "Only an authenticated admin can create accounts and assign roles." }, 403);

  let input: any;
  try { input = await req.json(); } catch { return json({ error: "Invalid JSON body." }, 400); }
  const name = String(input?.name || "").trim();
  const email = String(input?.email || "").trim().toLowerCase();
  const password = String(input?.password || "");
  const role = String(input?.role || "").toLowerCase();
  const phone = String(input?.phone || "").trim();
  const deg = String(input?.deg || "").trim();
  const spec = String(input?.spec || "").trim();
  if (name.length < 2 || !/^\S+@\S+\.\S+$/.test(email) || password.length < 8 || !["customer", "doctor", "admin"].includes(role)) {
    return json({ error: "Provide a valid name, email, password (at least 8 characters), and role." }, 400);
  }
  if (role === "doctor" && (!deg || !spec)) return json({ error: "Doctor qualification and speciality are required." }, 400);

  const { data: created, error: createError } = await adminClient.auth.admin.createUser({
    email, password, email_confirm: true, user_metadata: { name, phone, role },
  });
  if (createError || !created.user) return json({ error: createError?.message || "Supabase could not create the account." }, 400);
  const newUser = created.user;
  const { error: profileError } = await adminClient.from("profiles").upsert({
    id: newUser.id, name, email, phone: phone || null, role, updated_at: new Date().toISOString(),
  }, { onConflict: "id" });
  if (profileError) {
    await adminClient.auth.admin.deleteUser(newUser.id);
    return json({ error: `Profile save failed: ${profileError.message}` }, 500);
  }

  let doctor: any = null;
  if (role === "doctor") {
    const { data: row, error: doctorError } = await adminClient.from("doctors").insert({
      auth_user_id: newUser.id, name, deg, spec, email, active: true,
    }).select("id,auth_user_id,name,deg,spec,email,days,emoji,active").single();
    if (doctorError) {
      await adminClient.from("profiles").delete().eq("id", newUser.id);
      await adminClient.auth.admin.deleteUser(newUser.id);
      return json({ error: `Doctor directory save failed: ${doctorError.message}` }, 500);
    }
    doctor = row;
  }
  return json({ ok: true, user: { id: newUser.id, email, role }, doctor });
});
