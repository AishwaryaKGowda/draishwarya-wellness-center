# Dr. Aishwarya Wellness Center — Appointment Payment Test Plan and BigRock Hosting

## Test configuration warning

The appointment fee in this package has temporarily been changed to **₹5 (TEST ONLY)** across the booking UI, Razorpay order creation, payment verification and webhook validation. Use Razorpay **Test Mode keys** and the Razorpay test-mode dashboard only. Do not publish this ₹5 configuration for normal customers. Before production, restore the approved real consultation fee consistently in all four places (website UI, create order function, verify function, webhook) and test again.

The Supabase Edge Functions stay hosted on Supabase. BigRock hosts the static HTML website; it does not replace Supabase or Razorpay.

## Test cases

| ID | Scenario | Steps | Expected result | Evidence to check |
|---|---|---|---|---|
| AP-01 | Appointment fee shown | Open Book Appointment | Clearly shows ₹5 (TEST) and TEST MODE ONLY warning | Browser UI |
| AP-02 | Successful test payment | Select an active doctor, future date and free slot; enter valid test contact details; pay using Razorpay Test Mode | Server verifies signature and Razorpay payment; appointment becomes Confirmed/Paid | Success screen, `appointments` row, Razorpay test payment ID |
| AP-03 | Slot closes after payment | Refresh availability and select the same doctor/date/time | Paid/confirmed slot is no longer offered | Availability UI and database row |
| AP-04 | Second customer tries same slot | Open a second session and try the paid slot | Slot is rejected or hidden; server returns conflict; no second confirmed appointment | Function logs and `appointments` rows |
| AP-05 | Payment cancelled | Open checkout then dismiss it | Appointment is not Paid/Confirmed; slot is held only while pending reservation remains valid, then becomes available after expiry/cancellation handling | Database status and availability |
| AP-06 | Payment fails | Use a failed Razorpay test payment scenario | No Paid status and no success confirmation; clear retry/help message appears | Razorpay test dashboard and DB row |
| AP-07 | Signature/payment mismatch | Attempt verification with incorrect order/payment/signature in a safe test environment | Server rejects verification; no Paid status | Edge Function logs and row status |
| AP-08 | Email confirmation | Configure `RESEND_API_KEY` and verified `APPOINTMENT_FROM_EMAIL`; complete AP-02 | Email includes amount, doctor, date/time in IST, appointment reference, payment ID, WhatsApp contact link and QR code | Inbox and Resend logs |
| AP-09 | SMS confirmation | Configure MSG91 appointment template and secrets; complete AP-02 | MSG91 accepts SMS with appointment reference/date/time/fee variables | MSG91 logs and test phone |
| AP-10 | WhatsApp confirmation | Configure Meta WhatsApp Cloud API secrets and an approved template with five body variables; complete AP-02 | WhatsApp template message is accepted by Meta and delivered to an opted-in test number | Meta WhatsApp Manager logs and test phone |
| AP-11 | Missing provider credentials | Remove or omit a notification provider secret in a non-production test | Payment/booking stays confirmed; provider status is reported as not configured/failed in function logs; no false claim of delivery | Edge Function logs and response |
| AP-12 | Email WhatsApp link and QR | Open confirmation email on desktop and mobile; click link and scan QR with a phone | Both open the clinic WhatsApp contact (`+91 80881 55724`) | Email client and test phone |
| AP-13 | Customer details | Enter patient name, phone and email and book a test appointment | Same details and appointment reference persist in Supabase | `appointments` table |
| AP-14 | Admin appointment list | Sign in as authorized admin after AP-02 | Admin page shows confirmed appointment and Paid status | Admin portal and database |
| AP-15 | BigRock website hosting | Upload reviewed static site files to BigRock `public_html` on a staging/subdomain first | HTTPS website loads; booking page and public assets load | Browser, BigRock hosting panel |
| AP-16 | Supabase functions after BigRock deployment | Book a test appointment from BigRock-hosted website | Website still calls Supabase Edge Functions; no secret keys appear in browser source | Network tab and Supabase function logs |
| AP-17 | Production price guard | Before public launch, restore the approved fee everywhere and verify matching amount in order/verification/webhook | UI and server all agree on the real fee; ₹5 test mode is no longer visible | Code review and Razorpay test transaction |

## Required Supabase Edge Function secrets

Set secrets only in **Supabase Dashboard → Edge Functions → Secrets** or with `npx supabase secrets set`. Never place these in `index.html` or public files.

- Existing required: `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`
- Email: `RESEND_API_KEY`, `APPOINTMENT_FROM_EMAIL` (the sender must be verified in Resend)
- SMS (MSG91): `MSG91_AUTH_KEY`, `MSG91_APPOINTMENT_TEMPLATE_ID`
- WhatsApp Cloud API: `WHATSAPP_ACCESS_TOKEN`, `WHATSAPP_PHONE_NUMBER_ID`, `WHATSAPP_APPOINTMENT_TEMPLATE`, `WHATSAPP_TEMPLATE_LANG` (usually `en`)
- Webhook: `RAZORPAY_WEBHOOK_SECRET`

The MSG91 DLT template must accept variables in this order: `VAR1` appointment reference, `VAR2` date, `VAR3` time, `VAR4` fee. Ensure the DLT-approved SMS wording matches the template. The WhatsApp template must be approved by Meta and contain five body placeholders in this order: patient name, appointment reference, date, time, fee. Patients must have consented to SMS/WhatsApp communication. Provider acceptance is not proof of final delivery; check provider logs and the receiving device.

## Deploy Supabase functions

Run from the project root (the folder containing `index.html` and `supabase/`):

```powershell
npx supabase login
npx supabase link --project-ref nestxckkpbyfjpwsuiqu
npx supabase functions deploy create-appointment-razorpay-order --no-verify-jwt
npx supabase functions deploy verify-appointment-razorpay-payment --no-verify-jwt
npx supabase functions deploy book-appointment --no-verify-jwt
npx supabase functions deploy razorpay-webhook --no-verify-jwt
```

Use the actual Supabase project reference if it differs. Configure the Razorpay webhook in the Razorpay **Test Mode** dashboard to:

`https://YOUR_PROJECT_REF.supabase.co/functions/v1/razorpay-webhook`

Subscribe to `payment.captured`, `order.paid`, and `payment.failed`; configure `RAZORPAY_WEBHOOK_SECRET` in Supabase. Do not reuse API secret as webhook secret unless intentionally configured that way.

## BigRock hosting steps

1. **Keep a backup** of the currently published website and verify the test deployment on a staging subdomain if available.
2. Sign in to BigRock and open **Manage Orders → Web Hosting → Manage → cPanel** (labels may vary by plan).
3. Open **File Manager** and navigate to `public_html` for the target domain/subdomain.
4. Upload the reviewed website's root `index.html` and any required static assets/folders. This package's main website is a single HTML file, but keep the root `supabase/` directory in your local project for deployment of Edge Functions; do not expect BigRock to execute Supabase functions.
5. Enable SSL in BigRock for the domain and wait until HTTPS works before testing Razorpay checkout. Razorpay Checkout requires a secure site for production.
6. If the domain currently points to Netlify, do **not** change nameservers/DNS until ready: changing DNS can take the live site offline. First verify BigRock hosting and HTTPS on a staging subdomain, then make the planned DNS change with a rollback plan. Keep Supabase URL and publishable key configured in the frontend.
7. Open the HTTPS website in a private/incognito browser and test AP-01 through AP-16. Confirm Supabase calls succeed from the BigRock-hosted domain and inspect browser Console/Network for errors.
8. Do not make the website public with the ₹5 test fee. Restore the intended real fee and test again before launch.

## Completion criteria

The integration passes only when the appointment is Paid/Confirmed in Supabase after verified payment, the paid slot disappears from availability, a second customer cannot reserve that slot, configured notifications are accepted and actually received, and the website works over HTTPS on the intended BigRock domain. Do not mark SMS/email/WhatsApp as complete if provider credentials or approved templates are missing.
